//
//  SecondViewController.swift
//  TableView2
//
//  Created by Germán Santos Jaimes on 9/10/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var etiqueta: UILabel!
    var fromFirstView : String = ""
    @IBOutlet weak var descripts: UILabel!
    var fromFirstView2 : String = ""
    @IBOutlet weak var precio: UILabel!
    var fromFirstView3 : String = ""
    
    
    @IBOutlet weak var valor: UILabel!
    var dataFromFirstView : Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        etiqueta.text = fromFirstView
        descripts.text = fromFirstView2
        precio.text = fromFirstView3
        valor.text = String(dataFromFirstView)
        
    }

    @IBAction func incremento(_ sender: Any) {
        dataFromFirstView = dataFromFirstView + 230
        
        valor.text = String(dataFromFirstView)
    }
    
    
    }

