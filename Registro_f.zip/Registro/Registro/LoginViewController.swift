//
//  LoginViewController.swift
//  Registro
//
//  Created by Christian Hernández on 10/19/18.
//  Copyright © 2018 Christian Hernández. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var nombreUsuario: UITextField!
    
    @IBOutlet weak var passwordUsuario: UITextField!
    
    
    @IBOutlet weak var etiqueta: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "Background.jpg")!)

        // Do any additional setup after loading the view.
    }

    @IBAction func loginButton(_ sender: Any) {
        
        let usuario = nombreUsuario.text;
        
        let password = passwordUsuario.text;
        
        let usuarioG = UserDefaults.standard.string(forKey: "usuario")
        let passwordG = UserDefaults.standard.string(forKey: "password")
        
        if(usuarioG == usuario)
        {
            if(passwordG == password)
            {
                UserDefaults.standard.set(true, forKey: "logged")
                UserDefaults.standard.synchronize()
                self.dismiss(animated: true, completion: nil)
            }
        }
        
        if(usuarioG != usuario || passwordG != password )
        {
            etiqueta.text = "Usuario o contraseña incorrectos"
        }
        
    }
    
}
