//
//  botoncito.swift
//  TableView2
//
import UIKit

class botoncito: UIButton {

    override func awakeFromNib() {
     layer.borderColor = UIColor.black.cgColor
        
    }

}
