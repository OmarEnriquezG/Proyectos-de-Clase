//
//  ViewController.swift
//  TableView2
//
//  Created by Germán Santos Jaimes on 9/3/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    let ImageLista = ["Pizza", "nugget" ,"hotdog","alitas","hamburguesa"]
    
    @IBOutlet weak var tablita: UITableView!
    var alumnos = ["Menu 1","Menu 2","Menu 3","Menú 4","Menù 4"]
    
    var descript = ["Una pizza grande con un refresco de 1.5lt para 2 personas","Una orden de 24 nuggets con papas y 2 regrescos de 750ml"," 2 ordenes de Hotdogs con papas y refrescos","Una orden de 18 alitas con una orden de papas, aderezos y 2 refrescos","2 hamburguesas clásicas con papas y refrescos"]
    
    var precios = ["$230","$230","$230","$230","$230" ]
    
    @IBOutlet weak var carrito: UILabel!
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ImageLista.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        
        cell.imageView?.image = UIImage(named: ImageLista[indexPath.row])
        
        return cell
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    // Unwind Segues
    @IBAction func unwindSecondView(segue: UIStoryboardSegue){
        
        if let origin = segue.source as? SecondViewController{
            let data = origin.dataFromFirstView
            carrito.text = String(data)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? SecondViewController{
            destination.dataFromFirstView = Int(carrito.text!)!
        }
        if segue.identifier == "secondView"{
            
            let indexPath = tablita.indexPathForSelectedRow
            let destination = segue.destination as! SecondViewController
            
            destination.fromFirstView = alumnos[(indexPath?.row)!]
            destination.fromFirstView2 = descript[(indexPath?.row)!]
            destination.fromFirstView3 = precios[(indexPath?.row)!]
            
        }
    }


}




