# practica1_fdp
Primer práctica de la clase de fundamentos de programación.
