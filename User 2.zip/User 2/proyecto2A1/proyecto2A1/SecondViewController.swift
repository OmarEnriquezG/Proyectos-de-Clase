//
//  SecondViewController.swift
//  proyecto2A1
//
//  Created by Laboratorio UNAM-Apple 04 on 12/10/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    


}


/*
 var lista : [String] = []
 
 
 @IBOutlet weak var us: UITextField!
 
 
 override func viewDidLoad() {
 super.viewDidLoad()
 
 
 }
 
 @IBAction func registrar(_ sender: UIButton) {
 
 lista.append(us.text!)
 
 print (lista)
 }
*/


