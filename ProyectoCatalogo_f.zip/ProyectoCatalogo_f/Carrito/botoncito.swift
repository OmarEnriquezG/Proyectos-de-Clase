//
//  botoncito.swift
//  Carrito
//
import UIKit

class botoncito: UIButton {

    override func awakeFromNib() {
     layer.borderColor = UIColor.black.cgColor
        
    }

}
