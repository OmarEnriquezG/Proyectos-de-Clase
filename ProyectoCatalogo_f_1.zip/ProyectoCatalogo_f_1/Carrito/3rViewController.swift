//
//  3rViewController.swift
//  TableView2
//
//  Created by macbook on 02/10/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class _rViewController: UIViewController {

    @IBOutlet weak var resultado: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

