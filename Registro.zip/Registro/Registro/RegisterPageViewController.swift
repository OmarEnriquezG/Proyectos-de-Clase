//
//  RegisterPageViewController.swift
//  Registro
//
//  Created by Christian Hernández on 10/19/18.
//  Copyright © 2018 Christian Hernández. All rights reserved.
//

import UIKit

class RegisterPageViewController: UIViewController {

    @IBOutlet weak var nombreUsuario: UITextField!
    @IBOutlet weak var passwordUsuario: UITextField!
    @IBOutlet weak var confirmarPassword: UITextField!
    
    @IBOutlet weak var etiqueta: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

   
    @IBAction func regButton(_ sender: Any) {
        
        let usuario = nombreUsuario.text;
        let password = passwordUsuario.text;
        let confirmar = confirmarPassword.text;
        
        if((usuario?.isEmpty)! || (password?.isEmpty)! || (confirmar?.isEmpty)!)
        {
             etiqueta.text = "Debes llenar todos los campos"
            return;
        }
        if(password != confirmar)
        {
            etiqueta.text = "Las contrseñas no coinciden"
            return;
        }
        
        UserDefaults.standard.set(usuario, forKey:"usuario")
        UserDefaults.standard.set(password, forKey:"password")
        UserDefaults.standard.synchronize()
        
        self.dismiss( animated: true, completion: nil)
        
    }
    
        
    

}
