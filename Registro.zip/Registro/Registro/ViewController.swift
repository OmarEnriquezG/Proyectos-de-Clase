//
//  ViewController.swift
//  Registro
//
//  Created by Christian Hernández on 10/19/18.
//  Copyright © 2018 Christian Hernández. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewDidAppear(_ animated: Bool) {
        let logged = UserDefaults.standard.bool(forKey: "logged");
        if(!logged)
        {
            self.performSegue(withIdentifier: "loginView", sender: self)
        }
       
    }
    
    @IBAction func logOut(_ sender: Any) {
        UserDefaults.standard.set(false, forKey: "logged")
        UserDefaults.standard.synchronize()
        self.performSegue(withIdentifier: "loginView", sender: self)
    }
    

}
